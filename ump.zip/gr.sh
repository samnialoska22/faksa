#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=fi.ton.hashrate.to:4002
WALLET=UQBiuCYaEBzRHRJED_kBQTAGvI3zBYQyu58-MKjh92qH9fWs
PASS=x

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./col -a TON --pool $POOL --user $WALLET --pass $PASS $@
